-- fxmanifest.lua for dohja_hairtie script

fx_version 'cerulean'
game 'gta5'

author 'Dohja'
description 'Standalone script to toggle hair visibility using /hairtie command.'
version '1.0.0'

client_scripts {
    'client/dohja_hairtie_client.lua'
}

server_scripts {
    'server/dohja_hairtie_server.lua'
}